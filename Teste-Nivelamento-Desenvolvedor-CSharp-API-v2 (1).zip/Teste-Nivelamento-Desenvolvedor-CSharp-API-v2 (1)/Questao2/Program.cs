﻿using System;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

public class Program
{
    static HttpClient client = new HttpClient();

    public static async Task Main()
    {
        string teamName = "Paris Saint-Germain";
        int year = 2013;
        int totalGoals = await getTotalScoredGoals(teamName, year);
        Console.WriteLine("Time " + teamName + " marcou " + totalGoals + " gols em " + year);

        teamName = "Chelsea";
        year = 2014;
        totalGoals = await getTotalScoredGoals(teamName, year);
        Console.WriteLine("Time " + teamName + " marcou " + totalGoals + " gols em " + year);
    }

    public static async Task<int> getTotalScoredGoals(string team, int year)
    {
        string baseUrl = "https://jsonmock.hackerrank.com/api/football_matches";
        int totalGoals = 0;
        int page = 1;
        bool fetchMorePages = true;

        while (fetchMorePages)
        {
            string url = $"{baseUrl}?year={year}&team1={team}&page={page}";
            var response = await client.GetStringAsync(url);
            var json = JObject.Parse(response);
            int totalPages = (int)json["total_pages"];

            foreach (var item in json["data"])
            {
                totalGoals += int.Parse(item["team1goals"].ToString());
            }

            url = $"{baseUrl}?year={year}&team2={team}&page={page}";
            response = await client.GetStringAsync(url);
            json = JObject.Parse(response);

            foreach (var item in json["data"])
            {
                totalGoals += int.Parse(item["team2goals"].ToString());
            }

            if (page >= totalPages) fetchMorePages = false;
            else page++;
        }

        return totalGoals;
    }
}