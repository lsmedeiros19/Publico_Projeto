﻿using Dapper;
using Questao5.Domain.Entities;
using System.Data;

namespace Questao5.Infrastructure.Services
{
    public class ContaCorrenteService
    {
        private readonly IDbConnection _db;

        public ContaCorrenteService(IDbConnection db)
        {
            _db = db;
        }

        public async Task<IEnumerable<ContaCorrente>> GetAllContasCorrentes()
        {
            return await _db.QueryAsync<ContaCorrente>("SELECT * FROM contacorrente");
        }

        public async Task<int> AddContaCorrente(ContaCorrente conta)
        {
            var sql = "INSERT INTO contacorrente (idcontacorrente, numero, nome, ativo) VALUES (@IdContaCorrente, @Numero, @Nome, @Ativo)";
            return await _db.ExecuteAsync(sql, conta);
        }
    }
}
