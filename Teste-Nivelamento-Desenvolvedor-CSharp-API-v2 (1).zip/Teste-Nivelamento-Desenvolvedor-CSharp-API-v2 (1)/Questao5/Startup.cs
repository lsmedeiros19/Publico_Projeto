﻿using MediatR;
using Questao5.Infrastructure.Sqlite;
using System.Reflection;

namespace Questao5
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddMediatR(Assembly.GetExecutingAssembly());

            // Configuração do SQLite
            services.AddSingleton(new DatabaseConfig { Name = Configuration.GetValue<string>("DatabaseName", "Data Source=database.sqlite") });
            services.AddSingleton<IDatabaseBootstrap, DatabaseBootstrap>();

            // Swagger
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthorization();
            app.MapControllers();

            // Inicialização do banco de dados SQLite
            app.Services.GetService<IDatabaseBootstrap>()?.Setup();
        }
    }
}
