﻿namespace Questao5.Domain.Entities
{
    public class Idempotencia
    {
        public string ChaveIdempotencia { get; set; } // Chave de idempotência para a requisição
        public string Requisicao { get; set; } // Dados da requisição armazenados
        public string Resultado { get; set; } // Dados de retorno da requisição armazenados
    }
}
