﻿namespace Questao5.Domain.Entities
{
    public class Movimento
    {
        public string IdMovimento { get; set; } // Identificação única do movimento
        public string IdContaCorrente { get; set; } // Identificação da conta corrente relacionada
        public string DataMovimento { get; set; } // Data do movimento no formato DD/MM/YYYY
        public char TipoMovimento { get; set; } // Tipo do movimento ('C' = Crédito, 'D' = Débito)
        public double Valor { get; set; } // Valor do movimento com duas casas decimais

        public ContaCorrente ContaCorrente { get; set; } // Propriedade de navegação para a conta corrente
    }
}
