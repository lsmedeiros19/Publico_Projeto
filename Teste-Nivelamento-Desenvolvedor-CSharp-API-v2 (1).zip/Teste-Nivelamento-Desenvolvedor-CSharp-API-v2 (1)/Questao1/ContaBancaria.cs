﻿using System;
using System.Globalization;

namespace Questao1
{
    public class ContaBancaria
    {
        public int NumeroConta { get; private set; }
        public string Titular { get; set; }
        private double saldo;

        // Construtor para conta com depósito inicial
        public ContaBancaria(int numeroConta, string titular, double depositoInicial)
        {
            NumeroConta = numeroConta;
            Titular = titular;
            saldo = depositoInicial;
        }

        // Construtor para conta sem depósito inicial
        public ContaBancaria(int numeroConta, string titular)
        {
            NumeroConta = numeroConta;
            Titular = titular;
            saldo = 0; // Saldo inicial é zero
        }

        public void Deposito(double quantia)
        {
            if (quantia > 0)
            {
                saldo += quantia;
            }
        }

        public void Saque(double quantia)
        {
            const double taxaDeSaque = 3.50;
            if (quantia > 0 && (saldo + taxaDeSaque) >= quantia)
            {
                saldo -= (quantia + taxaDeSaque);
            }
            else
            {
                Console.WriteLine("Saldo insuficiente.");
            }
        }

        public override string ToString()
        {
            return $"Conta {NumeroConta}, Titular: {Titular}, Saldo: $ {saldo:0.00}";
        }
    }
}
